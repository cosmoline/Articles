import React, { Component } from 'react'

export default class users extends Component {
    render() {
        return (
            <div>
                User Page  
            </div>
        )
    }
}

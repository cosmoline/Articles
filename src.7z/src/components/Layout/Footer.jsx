import React from "react";
import './style.scss'

export default function Footer() {
  return <footer className={'footer'}>Page footer</footer>;
}
import React from "react";
import './style.scss'

export default function Header() {
  return <header className={'header'}>Page header</header>;
}